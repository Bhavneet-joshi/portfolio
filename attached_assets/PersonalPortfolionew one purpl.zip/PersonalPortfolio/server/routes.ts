import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMessageSchema } from "@shared/schema";
import axios from "axios";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  const GITHUB_API_BASE = "https://api.github.com";
  const GITHUB_USERNAME = "Bhavneet-joshi";

  // GitHub user profile endpoint
  app.get("/api/github/user", async (req, res) => {
    try {
      const response = await axios.get(`${GITHUB_API_BASE}/users/${GITHUB_USERNAME}`, {
        headers: {
          Accept: "application/vnd.github.v3+json",
        }
      });
      res.json(response.data);
    } catch (error) {
      console.error("Error fetching GitHub user data:", error);
      res.status(500).json({ error: "Failed to fetch GitHub user data" });
    }
  });

  // GitHub repositories endpoint
  app.get("/api/github/repos", async (req, res) => {
    try {
      const response = await axios.get(`${GITHUB_API_BASE}/users/${GITHUB_USERNAME}/repos`, {
        headers: {
          Accept: "application/vnd.github.v3+json",
        },
        params: {
          sort: "updated",
          per_page: 10
        }
      });
      
      // Filter useful information
      const repos = response.data.map((repo: any) => ({
        id: repo.id,
        name: repo.name,
        full_name: repo.full_name,
        html_url: repo.html_url,
        description: repo.description,
        language: repo.language,
        topics: repo.topics,
        stargazers_count: repo.stargazers_count,
        forks_count: repo.forks_count,
        updated_at: repo.updated_at
      }));
      
      res.json(repos);
    } catch (error) {
      console.error("Error fetching GitHub repos:", error);
      res.status(500).json({ error: "Failed to fetch GitHub repositories" });
    }
  });

  // Contact form endpoint
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertMessageSchema.parse(req.body);
      const savedMessage = await storage.createMessage(validatedData);
      res.status(201).json(savedMessage);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.format() });
      }
      res.status(500).json({ error: "Failed to save message" });
    }
  });

  return httpServer;
}
