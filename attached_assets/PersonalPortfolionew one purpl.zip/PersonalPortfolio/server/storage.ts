import { 
  users, messages, repositories,
  type User, type InsertUser,
  type Message, type InsertMessage,
  type Repository, type InsertRepository
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  
  // Repository methods
  getRepository(id: number): Promise<Repository | undefined>;
  getRepositories(): Promise<Repository[]>;
  createRepository(repo: InsertRepository): Promise<Repository>;
  updateRepository(id: number, repo: Partial<InsertRepository>): Promise<Repository | undefined>;
  
  // Message methods
  getMessage(id: number): Promise<Message | undefined>;
  getMessages(): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private repositories: Map<number, Repository>;
  private messages: Map<number, Message>;
  private userCurrentId: number;
  private repoCurrentId: number;
  private messageCurrentId: number;

  constructor() {
    this.users = new Map();
    this.repositories = new Map();
    this.messages = new Map();
    this.userCurrentId = 1;
    this.repoCurrentId = 1;
    this.messageCurrentId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updateData: Partial<InsertUser>): Promise<User | undefined> {
    const existingUser = this.users.get(id);
    if (!existingUser) return undefined;

    const updatedUser = { ...existingUser, ...updateData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Repository methods
  async getRepository(id: number): Promise<Repository | undefined> {
    return this.repositories.get(id);
  }

  async getRepositories(): Promise<Repository[]> {
    return Array.from(this.repositories.values());
  }

  async createRepository(insertRepo: InsertRepository): Promise<Repository> {
    const id = this.repoCurrentId++;
    const repo: Repository = { ...insertRepo, id };
    this.repositories.set(id, repo);
    return repo;
  }

  async updateRepository(id: number, updateData: Partial<InsertRepository>): Promise<Repository | undefined> {
    const existingRepo = this.repositories.get(id);
    if (!existingRepo) return undefined;

    const updatedRepo = { ...existingRepo, ...updateData };
    this.repositories.set(id, updatedRepo);
    return updatedRepo;
  }

  // Message methods
  async getMessage(id: number): Promise<Message | undefined> {
    return this.messages.get(id);
  }

  async getMessages(): Promise<Message[]> {
    return Array.from(this.messages.values());
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.messageCurrentId++;
    const message: Message = { 
      ...insertMessage, 
      id, 
      created_at: new Date()
    };
    this.messages.set(id, message);
    return message;
  }
}

export const storage = new MemStorage();
