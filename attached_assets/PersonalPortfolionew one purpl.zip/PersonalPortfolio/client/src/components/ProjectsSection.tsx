import ProjectCard from "@/components/ProjectCard";

interface ProjectsSectionProps {
  projects: any[];
}

const ProjectsSection = ({ projects }: ProjectsSectionProps) => {
  // Show only up to 6 projects
  const displayProjects = projects.length > 0 
    ? projects.slice(0, 6) 
    : [
        {
          id: 1,
          name: "Employee Dashboard",
          description: "A comprehensive dashboard for employee management with data visualization and reporting features.",
          html_url: "https://github.com/Bhavneet-joshi/employee-dashboard",
          topics: ["React", "Redux", "Node.js"],
          language: "JavaScript"
        },
        {
          id: 2,
          name: "E-commerce Platform",
          description: "A modern e-commerce solution with product management, cart functionality, and secure checkout.",
          html_url: "https://github.com/Bhavneet-joshi/ecommerce-platform",
          topics: ["Next.js", "MongoDB", "Stripe"],
          language: "TypeScript"
        },
        {
          id: 3,
          name: "Weather App",
          description: "Real-time weather forecasting app with location-based data and beautiful visualizations.",
          html_url: "https://github.com/Bhavneet-joshi/weather-app",
          topics: ["JavaScript", "API", "CSS"],
          language: "JavaScript"
        }
      ];

  return (
    <section 
      className="py-10 opacity-0 animate-fade-in" 
      style={{ animationDelay: "0.1s", animationFillMode: 'forwards' }}
    >
      <div className="bg-white rounded-3xl shadow-sm p-8 md:p-12">
        <h2 className="text-3xl font-bold text-text mb-8 flex items-center">
          <svg className="mr-3 text-primary" width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 6C3 5.46957 3.21071 4.96086 3.58579 4.58579C3.96086 4.21071 4.46957 4 5 4H19C19.5304 4 20.0391 4.21071 20.4142 4.58579C20.7893 4.96086 21 5.46957 21 6V18C21 18.5304 20.7893 19.0391 20.4142 19.4142C20.0391 19.7893 19.5304 20 19 20H5C4.46957 20 3.96086 19.7893 3.58579 19.4142C3.21071 19.0391 3 18.5304 3 18V6Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M3 6H21V10H3V6Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M7 15H7.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M11 15H13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          GitHub Projects
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayProjects.map((project, index) => (
            <ProjectCard key={project.id || index} project={project} />
          ))}
        </div>
        
        <div className="mt-8 text-center">
          <a 
            href="https://github.com/Bhavneet-joshi?tab=repositories" 
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-primary hover:bg-primary-dark text-white font-medium py-3 px-6 rounded-xl transition-colors"
          >
            View All Projects
          </a>
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;
