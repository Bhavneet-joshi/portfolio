import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Phone, Mail, MapPin, Github, Linkedin, Twitter, Dribbble } from "lucide-react";

const formSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  message: z.string().min(10, { message: "Message must be at least 10 characters." })
});

const ContactSection = () => {
  const { toast } = useToast();
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      message: ""
    }
  });

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    toast({
      title: "Message sent!",
      description: "Thank you for contacting me. I'll get back to you soon."
    });
    form.reset();
  };

  return (
    <section 
      id="contact" 
      className="py-10 opacity-0 animate-fade-in" 
      style={{ animationDelay: "0.3s", animationFillMode: 'forwards' }}
    >
      <div className="bg-white rounded-3xl shadow-sm overflow-hidden">
        <div className="flex flex-col md:flex-row">
          <div className="p-8 md:p-12 md:w-1/2">
            <h2 className="text-3xl font-bold text-text mb-6">Get In Touch</h2>
            <p className="text-text-secondary mb-8">
              Feel free to reach out for collaborations, project inquiries, or just to say hello!
            </p>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Your Name</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="John Doe" 
                          className="rounded-xl" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Address</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="john@example.com" 
                          className="rounded-xl" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Message</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Your message here..." 
                          className="rounded-xl h-32" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit" 
                  className="w-full bg-primary hover:bg-primary-dark text-white font-medium py-6 rounded-xl"
                >
                  Send Message
                </Button>
              </form>
            </Form>
          </div>
          
          <div className="gradient-bg p-8 md:p-12 md:w-1/2 flex flex-col justify-between"
              style={{ background: "linear-gradient(135deg, #7E57C2 0%, #B39DDB 100%)" }}
          >
            <div>
              <h3 className="text-xl font-semibold text-white mb-6">Contact Information</h3>
              
              <div className="space-y-4">
                <div className="flex items-start">
                  <Phone className="mr-4 text-white/80 mt-1" size={20} />
                  <div>
                    <h4 className="text-white/90 font-medium">Phone</h4>
                    <p className="text-white/80">+91 84374 74800</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Mail className="mr-4 text-white/80 mt-1" size={20} />
                  <div>
                    <h4 className="text-white/90 font-medium">Email</h4>
                    <p className="text-white/80">bhavneet0703@gmail.com</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <MapPin className="mr-4 text-white/80 mt-1" size={20} />
                  <div>
                    <h4 className="text-white/90 font-medium">Location</h4>
                    <p className="text-white/80">Malerkotla, Punjab, India</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-12">
              <h3 className="text-xl font-semibold text-white mb-4">Social Links</h3>
              <div className="flex space-x-4">
                <a 
                  href="https://github.com/Bhavneet-joshi" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-white/20 p-3 rounded-full hover:bg-white/30 transition-colors hover:scale-110 hover:shadow-glow"
                >
                  <Github className="text-white" size={20} />
                </a>
                <a 
                  href="https://www.linkedin.com/in/bhavneet-joshi/" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-white/20 p-3 rounded-full hover:bg-white/30 transition-colors hover:scale-110 hover:shadow-glow"
                >
                  <Linkedin className="text-white" size={20} />
                </a>
                <a 
                  href="mailto:bhavneet0703@gmail.com" 
                  className="bg-white/20 p-3 rounded-full hover:bg-white/30 transition-colors hover:scale-110 hover:shadow-glow"
                >
                  <Mail className="text-white" size={20} />
                </a>
                <a 
                  href="tel:+918437474800" 
                  className="bg-white/20 p-3 rounded-full hover:bg-white/30 transition-colors hover:scale-110 hover:shadow-glow"
                >
                  <Phone className="text-white" size={20} />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
