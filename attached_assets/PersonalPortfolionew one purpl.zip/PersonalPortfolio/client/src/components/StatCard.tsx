import { File, Star, Award, Bell } from "lucide-react";

interface StatCardProps {
  value: number;
  label: string;
  iconType: "file" | "star" | "tech" | "bell";
  colorClass: "primary" | "accent";
}

const StatCard = ({ value, label, iconType, colorClass }: StatCardProps) => {
  const renderIcon = () => {
    const iconProps = { 
      size: 24, 
      className: `text-${colorClass}` 
    };

    switch (iconType) {
      case "file":
        return <File {...iconProps} />;
      case "star":
        return <Star {...iconProps} />;
      case "tech":
        return <Award {...iconProps} />;
      case "bell":
        return <Bell {...iconProps} />;
      default:
        return <File {...iconProps} />;
    }
  };

  return (
    <div className="bg-background p-6 rounded-2xl transition-all duration-300 hover:shadow-md hover:-translate-y-1">
      <div className="flex justify-between items-start">
        <div>
          <span className="text-4xl font-bold text-text count-up" data-value={value}>0</span>
          <p className="text-text-secondary mt-1">{label}</p>
        </div>
        <div className={`bg-${colorClass}/10 p-3 rounded-xl`}>
          {renderIcon()}
        </div>
      </div>
    </div>
  );
};

export default StatCard;
