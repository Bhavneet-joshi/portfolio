import { Card } from "@/components/ui/card";
import { Github } from "lucide-react";

interface ProjectCardProps {
  project: any;
}

const ProjectCard = ({ project }: ProjectCardProps) => {
  // Generate a consistent image placeholder for each project
  const imageUrl = `https://source.unsplash.com/random/500x300/?${project.language?.toLowerCase() || 'code'}&sig=${project.id}`;
  
  // Extract up to 3 topics or generate placeholders based on language
  const topics = project.topics?.length > 0 
    ? project.topics.slice(0, 3) 
    : [project.language || "Code"];

  // Get project type for badge
  const getProjectType = () => {
    if (topics.some(t => t.toLowerCase().includes('react') || t.toLowerCase().includes('vue') || t.toLowerCase().includes('angular'))) {
      return "Frontend";
    } else if (topics.some(t => t.toLowerCase().includes('node') || t.toLowerCase().includes('express') || t.toLowerCase().includes('mongo'))) {
      return "Backend";
    } else if (topics.some(t => t.toLowerCase().includes('full') || (topics.includes('React') && topics.includes('Node.js')))) {
      return "Full-Stack";
    }
    return "Project";
  };

  return (
    <Card className="bg-white rounded-2xl overflow-hidden shadow-sm transition-all duration-300 hover:shadow-md hover:-translate-y-1">
      <div className="h-48 bg-primary/10 relative overflow-hidden">
        <img 
          src={imageUrl} 
          alt={`${project.name} Preview`} 
          className="w-full h-full object-cover"
        />
        <div className="absolute top-4 right-4">
          <span className="bg-background-card px-3 py-1 rounded-full text-xs font-medium text-primary">
            {getProjectType()}
          </span>
        </div>
      </div>
      <div className="p-6">
        <h3 className="text-xl font-bold text-text">{project.name}</h3>
        <p className="text-text-secondary mt-2 line-clamp-2">
          {project.description || `A ${project.language} project with various features and functionalities.`}
        </p>
        <div className="mt-4 flex items-center justify-between">
          <div className="flex flex-wrap gap-2">
            {topics.map((topic, index) => (
              <span key={index} className="bg-primary/10 px-2 py-1 rounded text-xs font-medium text-primary">
                {topic}
              </span>
            ))}
          </div>
          <a 
            href={project.html_url} 
            target="_blank"
            rel="noopener noreferrer"
            className="text-primary hover:text-primary-dark transition-colors"
          >
            <Github size={20} />
          </a>
        </div>
      </div>
    </Card>
  );
};

export default ProjectCard;
