import { Briefcase, Calendar } from "lucide-react";

const ExperienceSection = () => {
  const experienceData = [
    {
      id: 1,
      title: "Junior Engineer",
      company: "SMCK",
      period: "Oct 2024 - Present",
      description: [
        "Working with complex SQL queries, procedures, and subqueries for data optimization",
        "Developing networking skills for seamless system communication"
      ]
    },
    {
      id: 2,
      title: "Trainee Engineer",
      company: "Global Engineers",
      period: "Jan 2024 - Oct 2024",
      description: [
        "Gained experience in SQL query writing for data retrieval and manipulation",
        "Assisted in managing relational software focused on ASRS systems"
      ]
    },
    {
      id: 3,
      title: "Virtual Internship",
      company: "Accenture",
      period: "Aug 2023 - Sep 2023",
      description: [
        "Explored various tech roles and learned about the Software Development Lifecycle (SDLC)",
        "Worked with data visualization using Matplotlib and Plotly"
      ]
    }
  ];

  return (
    <section
      id="experience"
      className="py-10 opacity-0 animate-fade-in"
      style={{ animationDelay: "0.4s", animationFillMode: 'forwards' }}
    >
      <div className="bg-white rounded-3xl shadow-sm p-8 md:p-12">
        <h2 className="text-3xl font-bold text-text mb-8 flex items-center">
          <Briefcase className="mr-3 text-primary" size={28} />
          Work Experience
        </h2>

        <div className="space-y-10">
          {experienceData.map((item) => (
            <div key={item.id} className="relative">
              {/* Timeline dot */}
              <div className="absolute -left-3 top-0 w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                <div className="w-2 h-2 rounded-full bg-white"></div>
              </div>
              
              {/* Timeline line */}
              {item.id !== experienceData.length && (
                <div className="absolute -left-0 top-6 bottom-0 w-[1px] bg-primary/30"></div>
              )}
              
              {/* Content */}
              <div className="pl-8">
                <h3 className="text-xl font-semibold text-text">{item.title}</h3>
                <p className="text-primary font-medium mt-1">{item.company}</p>
                <div className="flex items-center mt-1 text-sm text-text-secondary">
                  <Calendar size={16} className="mr-1" />
                  <span>{item.period}</span>
                </div>
                <ul className="mt-3 space-y-1">
                  {item.description.map((desc, idx) => (
                    <li key={idx} className="text-text-secondary">
                      • {desc}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ExperienceSection;