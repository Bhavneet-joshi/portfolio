import { Card } from "@/components/ui/card";
import { ExternalLink } from "lucide-react";

interface CustomProjectProps {
  id: number;
  name: string;
  description: string;
  technologies: string[];
  type: "Backend" | "Frontend" | "Full-Stack";
  imageKeyword: string;
}

const CustomProjects = () => {
  // Custom projects as mentioned in the resume
  const projects: CustomProjectProps[] = [
    {
      id: 1,
      name: "Newspaper App",
      description: "A full-stack system for newspaper distribution, billing, and assignments using Java and SQL",
      technologies: ["Java", "SQL", "JDBC"],
      type: "Full-Stack",
      imageKeyword: "newspaper"
    },
    {
      id: 2,
      name: "Picture Pass",
      description: "A React.js-based project that integrates external APIs for dynamic data visualization and manipulation",
      technologies: ["React.js", "API Integration", "JavaScript"],
      type: "Frontend",
      imageKeyword: "gallery"
    },
    {
      id: 3,
      name: "Medcare",
      description: "A medicine donation and distribution platform using Bootstrap, Node.js, MySQL, and Tailwind CSS",
      technologies: ["Node.js", "MySQL", "Bootstrap", "Tailwind CSS"],
      type: "Full-Stack",
      imageKeyword: "healthcare"
    }
  ];

  return (
    <section
      id="custom-projects"
      className="py-10 opacity-0 animate-fade-in"
      style={{ animationDelay: "0.5s", animationFillMode: 'forwards' }}
    >
      <div className="bg-white rounded-3xl shadow-sm p-8 md:p-12">
        <h2 className="text-3xl font-bold text-text mb-8">Featured Projects</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project) => (
            <Card key={project.id} className="bg-white rounded-2xl overflow-hidden shadow-sm transition-all duration-300 hover:shadow-md hover:-translate-y-1">
              <div className="h-48 bg-primary/10 relative overflow-hidden">
                <img 
                  src={`https://source.unsplash.com/random/500x300/?${project.imageKeyword}&sig=${project.id}`}
                  alt={`${project.name} Preview`} 
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 right-4">
                  <span className="bg-background-card px-3 py-1 rounded-full text-xs font-medium text-primary">
                    {project.type}
                  </span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-text">{project.name}</h3>
                <p className="text-text-secondary mt-2 line-clamp-3">
                  {project.description}
                </p>
                <div className="mt-4 flex items-center justify-between">
                  <div className="flex flex-wrap gap-2">
                    {project.technologies.slice(0, 3).map((tech, index) => (
                      <span key={index} className="bg-primary/10 px-2 py-1 rounded text-xs font-medium text-primary">
                        {tech}
                      </span>
                    ))}
                  </div>
                  <a 
                    href="#"
                    className="text-primary hover:text-primary-dark transition-colors"
                  >
                    <ExternalLink size={20} />
                  </a>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CustomProjects;