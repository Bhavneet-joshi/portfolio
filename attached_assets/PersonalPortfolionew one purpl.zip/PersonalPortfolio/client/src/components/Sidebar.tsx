import { useState, useEffect } from "react";
import { scrollToSection } from "@/utils/scrollToSection";
import { Github, Linkedin } from "lucide-react";

const Sidebar = () => {
  const [activeSection, setActiveSection] = useState("about");

  useEffect(() => {
    const handleScroll = () => {
      const sections = ["about", "education", "experience", "portfolio", "skills", "contact"];
      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          if (rect.top <= 100 && rect.bottom >= 100) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <div className="w-16 fixed h-screen bg-white flex flex-col items-center justify-between py-8 border-r border-gray-200 z-10">
      <div className="mb-8">
        <a href="#" className="text-2xl font-bold text-primary">BJ</a>
      </div>
      <nav className="flex-grow flex flex-col items-center justify-center space-y-8">
        <a 
          href="#about" 
          onClick={(e) => scrollToSection(e, "about")}
          className={`nav-item text-sm font-medium transform writing-mode-vertical rotate-180 transition-all duration-300 ${activeSection === "about" ? "text-primary font-semibold" : "text-text-secondary"}`}
          style={{ writingMode: "vertical-lr", transform: "rotate(180deg)" }}
        >
          About
        </a>
        <a 
          href="#education" 
          onClick={(e) => scrollToSection(e, "education")}
          className={`nav-item text-sm font-medium transform writing-mode-vertical rotate-180 transition-all duration-300 ${activeSection === "education" ? "text-primary font-semibold" : "text-text-secondary"}`}
          style={{ writingMode: "vertical-lr", transform: "rotate(180deg)" }}
        >
          Education
        </a>
        <a 
          href="#experience" 
          onClick={(e) => scrollToSection(e, "experience")}
          className={`nav-item text-sm font-medium transform writing-mode-vertical rotate-180 transition-all duration-300 ${activeSection === "experience" ? "text-primary font-semibold" : "text-text-secondary"}`}
          style={{ writingMode: "vertical-lr", transform: "rotate(180deg)" }}
        >
          Experience
        </a>
        <a 
          href="#portfolio" 
          onClick={(e) => scrollToSection(e, "portfolio")}
          className={`nav-item text-sm font-medium transform writing-mode-vertical rotate-180 transition-all duration-300 ${activeSection === "portfolio" ? "text-primary font-semibold" : "text-text-secondary"}`}
          style={{ writingMode: "vertical-lr", transform: "rotate(180deg)" }}
        >
          Portfolio
        </a>
        <a 
          href="#skills"
          onClick={(e) => scrollToSection(e, "skills")}
          className={`nav-item text-sm font-medium transform writing-mode-vertical rotate-180 transition-all duration-300 ${activeSection === "skills" ? "text-primary font-semibold" : "text-text-secondary"}`}
          style={{ writingMode: "vertical-lr", transform: "rotate(180deg)" }}
        >
          Skills
        </a>
        <a 
          href="#contact"
          onClick={(e) => scrollToSection(e, "contact")}
          className={`nav-item text-sm font-medium transform writing-mode-vertical rotate-180 transition-all duration-300 ${activeSection === "contact" ? "text-primary font-semibold" : "text-text-secondary"}`}
          style={{ writingMode: "vertical-lr", transform: "rotate(180deg)" }}
        >
          Contact
        </a>
      </nav>
      <div className="mt-8 flex flex-col items-center space-y-4">
        <a 
          href="https://github.com/Bhavneet-joshi" 
          target="_blank" 
          rel="noopener noreferrer"
          className="text-text-secondary hover:text-primary transition-colors"
        >
          <Github size={24} />
        </a>
        <a 
          href="https://linkedin.com" 
          target="_blank" 
          rel="noopener noreferrer"
          className="text-text-secondary hover:text-primary transition-colors"
        >
          <Linkedin size={24} />
        </a>
      </div>
    </div>
  );
};

export default Sidebar;
