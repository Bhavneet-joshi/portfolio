import SkillBar from "@/components/SkillBar";
import { Briefcase, Server, Wrench } from "lucide-react";

const SkillsSection = () => {
  const frontendSkills = [
    { name: "React", percentage: 85 },
    { name: "JavaScript", percentage: 80 },
    { name: "Tailwind CSS", percentage: 78 },
    { name: "Bootstrap", percentage: 82 },
    { name: "HTML/CSS", percentage: 90 }
  ];

  const backendSkills = [
    { name: "Java", percentage: 75 },
    { name: "SQL", percentage: 85 },
    { name: "C/C++", percentage: 78 },
    { name: "Node.js", percentage: 70 },
    { name: "Database Design", percentage: 80 }
  ];

  const tools = [
    "Git", "GitHub", "VS Code", "Matplotlib", "Plotly", "MySQL", 
    "React.js", "Tailwind CSS", "Bootstrap", "Node.js", "SQL", "REST APIs",
    "Postman", "JDBC", "Data Structures", "Algorithms"
  ];

  return (
    <section 
      id="skills" 
      className="py-10 opacity-0 animate-fade-in" 
      style={{ animationDelay: "0.2s", animationFillMode: 'forwards' }}
    >
      <div className="bg-white rounded-3xl shadow-sm p-8 md:p-12">
        <h2 className="text-3xl font-bold text-text mb-8">Skills & Technologies</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Frontend Skills */}
          <div className="relative">
            <div className="absolute -left-3 top-0 w-6 h-6 rounded-full bg-primary flex items-center justify-center timeline-dot">
              <div className="w-2 h-2 rounded-full bg-white"></div>
            </div>
            
            <h3 className="text-xl font-semibold text-text mb-6 pl-6 flex items-center">
              <Briefcase className="mr-2 text-primary" size={24} />
              Frontend Development
            </h3>
            
            <div className="space-y-6 pl-6">
              {frontendSkills.map((skill, index) => (
                <SkillBar 
                  key={index} 
                  name={skill.name} 
                  percentage={skill.percentage} 
                />
              ))}
            </div>
          </div>
          
          {/* Backend Skills */}
          <div className="relative">
            <div className="absolute -left-3 top-0 w-6 h-6 rounded-full bg-primary flex items-center justify-center timeline-dot" style={{ animationDelay: "0.5s" }}>
              <div className="w-2 h-2 rounded-full bg-white"></div>
            </div>
            
            <h3 className="text-xl font-semibold text-text mb-6 pl-6 flex items-center">
              <Server className="mr-2 text-primary" size={24} />
              Backend Development
            </h3>
            
            <div className="space-y-6 pl-6">
              {backendSkills.map((skill, index) => (
                <SkillBar 
                  key={index} 
                  name={skill.name} 
                  percentage={skill.percentage} 
                />
              ))}
            </div>
          </div>
        </div>
        
        {/* Tools & Other Skills */}
        <div className="mt-14 relative">
          <div className="absolute -left-3 top-0 w-6 h-6 rounded-full bg-primary flex items-center justify-center timeline-dot" style={{ animationDelay: "1s" }}>
            <div className="w-2 h-2 rounded-full bg-white"></div>
          </div>
          
          <h3 className="text-xl font-semibold text-text mb-6 pl-6 flex items-center">
            <Wrench className="mr-2 text-primary" size={24} />
            Tools & Expertise
          </h3>
          
          <div className="flex flex-wrap gap-3 pl-6">
            {tools.map((tool, index) => (
              <span 
                key={index} 
                className="px-4 py-2 rounded-lg bg-primary/10 text-primary font-medium hover:bg-primary hover:text-white transition-colors duration-300 cursor-default"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {tool}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
