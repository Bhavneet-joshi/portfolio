const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="py-6 text-center text-text-secondary border-t border-gray-200 mt-8">
      <p>© {currentYear} Bhavneet Joshi. All rights reserved.</p>
    </footer>
  );
};

export default Footer;
