import { useEffect, useRef } from "react";
import StatCard from "@/components/StatCard";
import { initCounterAnimation } from "@/utils/counterAnimation";
import { Mail, MapPin, ExternalLink } from "lucide-react";

interface AboutSectionProps {
  githubUser: {
    avatar_url?: string;
    name?: string;
    bio?: string;
    email?: string;
    location?: string;
    public_repos?: number;
    public_gists?: number;
    [key: string]: any;
  };
  reposCount: number;
}

const AboutSection = ({ githubUser, reposCount }: AboutSectionProps) => {
  const countersRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (countersRef.current) {
      initCounterAnimation(countersRef.current);
    }
  }, []);

  return (
    <section id="about" className="py-10 opacity-0 animate-fade-in" style={{ animationFillMode: 'forwards' }}>
      <div className="bg-white rounded-3xl shadow-sm overflow-hidden">
        <div className="flex flex-col md:flex-row">
          {/* Profile Information */}
          <div className="bg-primary p-8 md:p-12 md:w-2/5 flex flex-col justify-between">
            <div>
              <div className="profile-circle w-36 h-36 p-1 rounded-full" style={{ background: "linear-gradient(135deg, #B39DDB 0%, #F48FB1 100%)" }}>
                <div className="bg-white rounded-full w-full h-full flex items-center justify-center overflow-hidden">
                  <img 
                    src={githubUser?.avatar_url || "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/github/github-original.svg"} 
                    alt="Profile" 
                    className="object-cover w-full h-full"
                  />
                </div>
              </div>
              <h1 className="text-4xl font-bold text-white mt-6">
                {githubUser?.name || "Bhavneet Joshi"}
              </h1>
              <h2 className="text-xl font-medium text-primary-light mt-2">
                {githubUser?.bio || "Full Stack Developer"}
              </h2>
              <p className="text-white/80 mt-4 max-w-md">
                Full Stack Developer with experience in multiple programming languages including C, C++, JavaScript, SQL, and Java. 
                Passionate about clean, efficient coding and creating responsive web applications.
              </p>
            </div>
            <div className="mt-12">
              <a href={`mailto:${githubUser?.email || "contact@bhavneetjoshi.com"}`} 
                 className="text-white/90 flex items-center hover:text-white transition-colors">
                <Mail className="mr-2" size={20} />
                {githubUser?.email || "contact@bhavneetjoshi.com"}
              </a>
              <div className="flex items-center text-white/90 mt-2">
                <MapPin className="mr-2" size={20} />
                {githubUser?.location || "Bengaluru, India"}
              </div>
            </div>
          </div>
          
          {/* Stats Cards */}
          <div className="p-8 md:p-12 md:w-3/5">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-3xl font-bold text-text">Portfolio</h2>
              <a 
                href="https://github.com/Bhavneet-joshi" 
                className="text-primary hover:text-primary-dark transition-colors flex items-center text-sm"
                target="_blank"
                rel="noopener noreferrer"
              >
                View GitHub Profile
                <ExternalLink className="ml-1" size={18} />
              </a>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4" ref={countersRef}>
              <StatCard 
                value={reposCount || 15} 
                label="Projects" 
                iconType="file"
                colorClass="primary"
              />
              
              <StatCard 
                value={githubUser?.public_repos || 12} 
                label="Repositories" 
                iconType="star"
                colorClass="accent"
              />
              
              <StatCard 
                value={8} 
                label="Technologies" 
                iconType="tech"
                colorClass="primary"
              />
              
              <StatCard 
                value={githubUser?.public_gists || 250} 
                label="Contributions" 
                iconType="bell"
                colorClass="accent"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
