interface SkillBarProps {
  name: string;
  percentage: number;
}

const SkillBar = ({ name, percentage }: SkillBarProps) => {
  return (
    <div className="relative">
      <div className="flex justify-between mb-1">
        <span className="text-sm font-medium text-text">{name}</span>
        <span className="text-sm font-medium text-text-secondary">{percentage}%</span>
      </div>
      <div className="h-2.5 bg-primary/10 rounded-full overflow-hidden">
        <div 
          className="h-2.5 bg-gradient-to-r from-primary to-primary-dark rounded-full skill-bar-fill" 
          style={{ '--percent': `${percentage}%` } as React.CSSProperties}
        >
          <div className="absolute right-0 top-0 h-full w-2 bg-white opacity-40"></div>
        </div>
      </div>
    </div>
  );
};

export default SkillBar;
