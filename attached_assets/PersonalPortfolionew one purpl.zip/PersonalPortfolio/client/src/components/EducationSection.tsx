import { GraduationCap, Calendar } from "lucide-react";

const EducationSection = () => {
  const educationData = [
    {
      id: 1,
      degree: "B.Tech in Computer Science Engineering",
      institution: "Giani Zail Singh Campus College",
      period: "2020 - 2024",
      gpa: "7.28 CGPA",
      achievements: [
        "Data Structures and Algorithms",
        "Object-Oriented Programming",
        "Database Management Systems",
        "Software Engineering"
      ]
    },
    {
      id: 2,
      degree: "Higher Secondary Education",
      institution: "GSSS Darkhana Road, Malerkotla",
      period: "2018 - 2020",
      gpa: "8.6 CGPA",
      achievements: [
        "Physics, Chemistry and Mathematics",
        "Computer Science",
        "English and Punjabi"
      ]
    }
  ];

  return (
    <section
      id="education"
      className="py-10 opacity-0 animate-fade-in"
      style={{ animationDelay: "0.3s", animationFillMode: 'forwards' }}
    >
      <div className="bg-white rounded-3xl shadow-sm p-8 md:p-12">
        <h2 className="text-3xl font-bold text-text mb-8 flex items-center">
          <GraduationCap className="mr-3 text-primary" size={28} />
          Education
        </h2>

        <div className="space-y-10">
          {educationData.map((item) => (
            <div key={item.id} className="relative">
              {/* Timeline dot */}
              <div className="absolute -left-3 top-0 w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                <div className="w-2 h-2 rounded-full bg-white"></div>
              </div>
              
              {/* Timeline line */}
              {item.id !== educationData.length && (
                <div className="absolute -left-0 top-6 bottom-0 w-[1px] bg-primary/30"></div>
              )}
              
              {/* Content */}
              <div className="pl-8">
                <h3 className="text-xl font-semibold text-text">{item.degree}</h3>
                <p className="text-primary font-medium mt-1">{item.institution}</p>
                <div className="flex items-center justify-between mt-1">
                  <div className="flex items-center text-sm text-text-secondary">
                    <Calendar size={16} className="mr-1" />
                    <span>{item.period}</span>
                  </div>
                  <div className="text-sm font-medium text-text">
                    {item.gpa}
                  </div>
                </div>
                <ul className="mt-3 space-y-1">
                  {item.achievements.map((achievement, idx) => (
                    <li key={idx} className="text-text-secondary">
                      • {achievement}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default EducationSection;