import { useEffect } from "react";
import Sidebar from "@/components/Sidebar";
import AboutSection from "@/components/AboutSection";
import EducationSection from "@/components/EducationSection";
import ExperienceSection from "@/components/ExperienceSection";
import ProjectsSection from "@/components/ProjectsSection";
import CustomProjects from "@/components/CustomProjects";
import SkillsSection from "@/components/SkillsSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

const Home = () => {
  const { toast } = useToast();
  
  // Query GitHub user profile data
  const { data: githubUser, isError: userError } = useQuery({
    queryKey: ['/api/github/user'],
    retry: 2
  });
  
  // Query GitHub repositories data
  const { data: githubRepos, isError: reposError } = useQuery({
    queryKey: ['/api/github/repos'],
    retry: 2
  });

  useEffect(() => {
    if (userError || reposError) {
      toast({
        title: "Error loading data",
        description: "Could not fetch GitHub data. Please try again later.",
        variant: "destructive"
      });
    }
  }, [userError, reposError, toast]);

  return (
    <div className="min-h-screen flex bg-background">
      <Sidebar />
      <div className="ml-16 w-full">
        <div className="container mx-auto px-4 py-8 max-w-7xl">
          <AboutSection githubUser={githubUser || {}} reposCount={Array.isArray(githubRepos) ? githubRepos.length : 0} />
          <EducationSection />
          <ExperienceSection />
          <div id="portfolio">
            <ProjectsSection projects={Array.isArray(githubRepos) ? githubRepos : []} />
            <CustomProjects />
          </div>
          <SkillsSection />
          <ContactSection />
          <Footer />
        </div>
      </div>
    </div>
  );
};

export default Home;
