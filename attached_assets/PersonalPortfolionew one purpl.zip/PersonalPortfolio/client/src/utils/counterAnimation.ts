export const initCounterAnimation = (container: HTMLElement) => {
  const counters = container.querySelectorAll('.count-up');
  
  const animateCounter = (counter: Element) => {
    const target = parseInt(counter.getAttribute('data-value') || '0', 10);
    let count = 0;
    const duration = 1000; // ms
    const interval = Math.max(10, Math.floor(duration / target));
    const increment = Math.max(1, Math.ceil(target / (duration / interval)));
    
    const timer = setInterval(() => {
      count += increment;
      if (count >= target) {
        counter.textContent = target.toString();
        clearInterval(timer);
      } else {
        counter.textContent = count.toString();
      }
    }, interval);
  };
  
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });
  
  counters.forEach(counter => {
    observer.observe(counter);
  });
};
