import { pgTable, text, serial, integer, json, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Schema for GitHub repositories
export const repositories = pgTable("repositories", {
  id: serial("id").primaryKey(),
  repo_id: integer("repo_id").notNull().unique(),
  name: text("name").notNull(),
  full_name: text("full_name").notNull(),
  html_url: text("html_url").notNull(),
  description: text("description"),
  language: text("language"),
  topics: json("topics").$type<string[]>(),
  stargazers_count: integer("stargazers_count").default(0),
  forks_count: integer("forks_count").default(0),
  updated_at: timestamp("updated_at").notNull(),
});

// Schema for GitHub user profile
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull().unique(),
  username: text("username").notNull().unique(),
  name: text("name"),
  avatar_url: text("avatar_url"),
  bio: text("bio"),
  location: text("location"),
  email: text("email"),
  public_repos: integer("public_repos").default(0),
  public_gists: integer("public_gists").default(0),
  followers: integer("followers").default(0),
  following: integer("following").default(0),
  updated_at: timestamp("updated_at").notNull(),
});

// Contact form messages
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  message: text("message").notNull(),
  created_at: timestamp("created_at").defaultNow().notNull(),
});

// Define insert schemas
export const insertRepositorySchema = createInsertSchema(repositories).omit({ id: true });
export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, created_at: true });

// Define types
export type InsertRepository = z.infer<typeof insertRepositorySchema>;
export type Repository = typeof repositories.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;
